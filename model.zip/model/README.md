# Instructions to run code

1. Open Terminal

2. Change the current working directory to "model" directory. for eg "BBC-Dataset-News-Classification-master/model"

3. Run => python get_data.py

It will create "dataset.csv" csv file in dataset folder

4. Run => python model.py
